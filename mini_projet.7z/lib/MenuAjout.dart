import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;

import 'Analyse.dart';
import 'RadioScanner.dart';
import 'certeficat.dart';

class Ajout extends StatefulWidget {
  Ajout({Key? key, this.medicament, this.imageA, this.imageR}) : super(key: key);

  final List<ContainerItem>? medicament;
  final File? imageA;
  final File? imageR;

  @override
  _AjoutState createState() => _AjoutState();
}

class _AjoutState extends State<Ajout> {
  final TextEditingController _maladieController = TextEditingController();

  @override
  void dispose() {
    _maladieController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(69, 169, 230, 1),
        toolbarHeight: 80.0,
        title: Text(
          'Analyses',
          style: TextStyle(fontSize: 30.0),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _maladieController,
              decoration: InputDecoration(
                labelText: 'Maladie',
                labelStyle: TextStyle(color: Colors.grey),
                hintText: 'Ex: Grippe',
                hintStyle: TextStyle(color: Colors.grey),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.blue, width: 2.0),
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Certeficat()),
                );
              },
              child: Text("Ajouter medicament"),
            ),
            TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => RS()),
                );
              },
              child: Text("Ajouter Radio"),
            ),
            TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => Analyse()),
                );
              },
              child: Text("Ajouter Analyse"),
            ),
            SizedBox(
              height: 16,
            ),
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextButton(
                    onPressed: () =>
                        addItemsToFirestore(widget.medicament),
                    child: Text("Ajouter"),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Future<void> addItemsToFirestore(List<ContainerItem>? items) async {
  if (items == null) return;

  // Get a reference to the Firestore instance
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  // Get a reference to the collection that will hold the list of items
  final CollectionReference containerItemsCollection =
  firestore.collection('users').doc('Engel').collection('Medicament');
  // Loop through the items and create a document for each item in the collection
  for (ContainerItem item in items) {
    await containerItemsCollection.add({
      'text1': item.text1,
      'text2': item.text2,
      'isChecked': item.isChecked,
      'date': item.date,
    });
  }
}

