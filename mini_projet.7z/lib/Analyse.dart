import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:path/path.dart';





class Analyse extends StatefulWidget {
  @override
  _Analyse createState() => _Analyse();
}

class _Analyse extends State<Analyse> {
  List<String> _choices = ['Bilan lipidique ', 'Glycémie', 'Ionogramme sanguin', 'Bilan thyroïdien', 'Bilan rénal'];
  String _selectedChoice = 'Glycémie';
  TextEditingController _textController = TextEditingController();
  String _imagePath = ''; // Initialisation de la variable _imagePath avec une valeur par défaut

  Future getImage() async {
    final pickedFile = await picker.getImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
        uploadImageToFirebaseStorage(_image); // Upload the image to Firebase storage
      } else {
        print('No image selected.');
      }
    });
  }
  Future<void> uploadImageToFirebaseStorage(File file) async {
    try {
      // Create a reference to the Firebase storage location
      String fileName = basename(file.path);
      firebase_storage.Reference reference =
      firebase_storage.FirebaseStorage.instance.ref('images/analyse/$fileName');

      // Upload the file to Firebase storage
      await reference.putFile(file);

      // Get the download URL of the uploaded file
      String downloadURL = await reference.getDownloadURL();
      print('Download URL: $downloadURL');
    } catch (e) {
      print('Error uploading image to Firebase storage: $e');
    }
  }
  late File _image;
  final picker = ImagePicker();



  @override
  void initState() {
    super.initState();
    _image = File(''); // initialiser la variable _image avec une valeur nulle
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(69, 169, 230, 1),
        toolbarHeight: 80.0,
        title: Text('Analyses', style:TextStyle(fontSize: 30.0),),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 20,),

            Container(
              width: double.infinity,
              margin: EdgeInsets.symmetric(horizontal: 20.0),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                border: Border.all(
                  color: Colors.black12,
                  width: 2.0,
                ),
              ),
              child: DropdownButton(
                value: _selectedChoice,
                items: _choices.map((String choice) {
                  return DropdownMenuItem(
                    value: choice,
                    child: Text(choice),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedChoice = value.toString();
                    String _imagePath = '';
                  });
                },
                style: TextStyle(
                  color: Colors.black54,
                  fontSize: 16.0,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Arial',
                ),
                icon: Icon(
                  Icons.arrow_drop_down,
                  color: Colors.blue,
                ),
                isExpanded: true,
                underline: Container(),
              ),
            ),



            SizedBox(height: 16,),
            TextField(
              decoration: InputDecoration(
                labelText: 'Observation du Docteur ',
                labelStyle: TextStyle(color: Colors.grey),
                hintText: 'Ex: une légère augmentation des neutrophiles ',
                hintStyle: TextStyle(color: Colors.grey),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.blue, width: 2.0),
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ),
            Center(
              child:Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [


                ],
              ),
            ),


            SizedBox(height: 30.0),
            Center(
              child: _image.path.isEmpty
                  ? Text('Aucune image sélectionée ',   style: TextStyle(
                fontSize: 22.0,
              ),)
                  : Image.file(_image),
            ),
            SizedBox(height: 16.0),
            Center(
              child: ElevatedButton(
                onPressed: getImage,
                child: Text('Telecharger une photo ',   style: TextStyle(
                  fontSize: 22.0,
                ),),
                style: ElevatedButton.styleFrom(
                  primary: Color.fromRGBO(69, 169, 230, 1),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  minimumSize: Size(120, 50), // définir la taille minimale
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

