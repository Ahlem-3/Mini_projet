import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class ContainerItem {
  String text1;
  String text2;
  bool isChecked;
  DateTime date;

  ContainerItem({required this.text1, required this.text2, required this.isChecked, required this.date});
}

class Certeficat extends StatefulWidget {
  @override
  _Certeficat createState() => _Certeficat();
}

class _Certeficat extends State<Certeficat> {
  List<ContainerItem> _items = [];

  TextEditingController _text1Controller = TextEditingController();
  TextEditingController _text2Controller = TextEditingController();
  DateTime _selectedDate = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(240, 236, 234, 1),
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(69, 169, 230, 1),
        toolbarHeight: 80.0,
        title: Text('Mes Medicaments en cours'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 30.0),
          Column(
            children: [
              TextField(
                controller: _text1Controller,
                decoration: InputDecoration(
                  labelText: 'Nom Medicaments',
                  labelStyle: TextStyle(color: Colors.grey),
                  hintText: 'Ex: Paracetamol',
                  hintStyle: TextStyle(color: Colors.grey),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.blue, width: 2.0),
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ),

              SizedBox(height: 16.0),
              TextField(
                controller: _text2Controller,
                decoration: InputDecoration(
                  labelText: 'Fréquence de prise',
                  labelStyle: TextStyle(color: Colors.grey),
                  hintText: 'Ex: 2 fois par jour ',
                  hintStyle: TextStyle(color: Colors.grey),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.blue, width: 2.0),
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ),


              SizedBox(height: 16.0),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextButton(
                    onPressed: _showDatePicker,
                    child: Text(
                      DateFormat('dd/MM/yyyy').format(_selectedDate),
                      style: TextStyle(fontSize: 30.0,color:Color.fromRGBO(69, 169, 230, 1),),

                    ),

                  ),
                  SizedBox(width: 16.0),
                  ElevatedButton(
                    onPressed: _addItem,
                    child: Text('Ajouter',   style: TextStyle(
                      fontSize: 22.0,
                    ),),
                    style: ElevatedButton.styleFrom(
                      primary: Color.fromRGBO(69, 169, 230, 1),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      minimumSize: Size(120, 50), // définir la taille minimale
                    ),
                  ),
                  ElevatedButton(
                    onPressed:  () => addItemsToFirestore(_items),
                    child: Text('Ajouter bdd',   style: TextStyle(
                      fontSize: 22.0,
                    ),),
                    style: ElevatedButton.styleFrom(
                      primary: Color.fromRGBO(69, 169, 230, 1),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      minimumSize: Size(120, 50), // définir la taille minimale
                    ),
                  ),

                ],
              ),
            ],
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _items.length,
              itemBuilder: (BuildContext context, int index) {
                final item = _items[index];

                return Dismissible(
                  key: Key(index.toString()),
                  onDismissed: (direction) {
                    setState(() {
                      _items.removeAt(index);
                    });
                  },
                  child: Container(

                    height: 120,
                    width: double.infinity,
                    margin: EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: Colors.white),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(height: 20,),
                            Text(
                              _items[index].text1,
                              style: TextStyle(
                                fontSize: 30.0,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 10.0),
                            Text(
                              _items[index].text2,
                              style: TextStyle(
                                fontSize: 20.0,
                              ),
                            ),
                          ],
                        ),
                        Text(
                          DateFormat('dd/MM/yyyy').format(_items[index].date),
                          style: TextStyle(fontSize: 20.0),
                        ),
                        Checkbox(

                          value: _items[index].isChecked,
                          onChanged: (value) {
                            setState(() {
                              _items[index].isChecked = value!;
                            });
                          },
                        ),
                      ],
                    ),
                  ),
                  background: Container(
                    color: Colors.red,
                    child: Icon(Icons.delete, color: Colors.white),
                    alignment: Alignment.centerRight,
                    padding: EdgeInsets.only(right: 16.0),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _addItem() {
    final text1 = _text1Controller.text;
    final text2 = _text2Controller.text;
    final isChecked = false;
    final date = _selectedDate;

    if (text1.isNotEmpty && text2.isNotEmpty) {
      setState(() {
        _items.add(ContainerItem(
          text1: text1,
          text2: text2,
          isChecked: isChecked,
          date: date,
        ));
      });

      _text1Controller.clear();
      _text2Controller.clear();
      _selectedDate = DateTime.now();
    }
  }

  void _showDatePicker() async {
    DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(1900),
      lastDate: DateTime(2100),
    );
    if (pickedDate != null) {
      setState(() {
        _selectedDate = pickedDate;
      });
    }
  }

  @override
  void dispose() {
    _text1Controller.dispose();
    _text2Controller.dispose();
    super.dispose();
  }
  Future<void> addItemsToFirestore(List<ContainerItem> items) async {
    // Get a reference to the Firestore instance
    final FirebaseFirestore firestore = FirebaseFirestore.instance;

    // Get a reference to the collection that will hold the list of items
    final CollectionReference containerItemsCollection = firestore.collection('users').doc('Engel').collection('Medicament');

    // Loop through the items and create a document for each item in the collection
    for (ContainerItem item in items) {
      await containerItemsCollection.add({
        'text1': item.text1,
        'text2': item.text2,
        'isChecked': item.isChecked,
        'date': item.date,
      });
    }
  }
}

