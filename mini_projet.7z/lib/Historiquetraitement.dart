import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Htraitement extends StatefulWidget {
  Htraitement({super.key, required this.username}) ;

  final String username;

  @override
  _Htraitement createState() => _Htraitement();
}

class _Htraitement extends State<Htraitement> {
  Stream<QuerySnapshot>? _usersStream;

  @override
  void initState() {
    super.initState();
    if (widget.username.isNotEmpty) {
      _usersStream = FirebaseFirestore.instance
          .collection('users')
          .doc(widget.username)
          .collection('Medicament')
          .orderBy('date', descending: true)
          .snapshots();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder<QuerySnapshot>(
        stream: _usersStream,
        builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text('Something went wrong'),
            );
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(
              child: Text('No data found'),
            );
          }

          return ListView(
            children: snapshot.data!.docs.map((DocumentSnapshot document) {
              Map<String, dynamic> data =
              document.data()! as Map<String, dynamic>;
              return ListTile(
                title: Text(data['NomMedicament'].toString()),
                subtitle: Text(data['Nombredeprise'].toString()),
                onTap: () {
                  String docId = document.id;
                  print(docId);// Get the ID of the document
                  // Do something with the document ID, such as navigating to a new page
                },

              );
            }).toList(),
          );
        },
      ),
    );
  }
}
