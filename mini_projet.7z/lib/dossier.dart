import 'package:firebase_auth/firebase_auth.dart';
import 'package:mini_projet/Analyse.dart';
import 'certeficat.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'informationPerso.dart';
import 'Historiquetraitement.dart';
import 'RadioScanner.dart';
import 'Login.dart';
import 'Alergies et maladie chronique.dart';
import 'Analyse.dart';
import 'MenuAjout.dart';
import 'afficherRadio.dart';
class Dossier extends StatelessWidget {
   Dossier({super.key,required this.username});
  String username;
   final FirebaseAuth _auth = FirebaseAuth.instance;


  @override
  Widget build(BuildContext context) {
    return SafeArea(


      child: Scaffold(
        appBar: AppBar(
          toolbarHeight: 60.0,
          elevation: 10,
          leading:Container(

            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white,
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(35),
              child: Image.asset('assets/images/user.png', fit: BoxFit.fill),
            ),
          ),
          backgroundColor: Color.fromRGBO(84, 160, 255, 1),
        ),
        body: SingleChildScrollView(
          child: Center(
            // Center is a layout widget. It takes a single child and positions it
            // in the middle of the parent.
            child: Column(

                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  Container(
                      height: 20.0,

                     // child: Image.asset('assets/images/logo2.png')
                  ),
                  SizedBox(
                    height: 30.0,
                  ),

                  SizedBox(
                    height: 20.0,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Card(


                        child: Container(
                          //  color: Colors.deepOrangeAccent,
                          height:90.0,
                          width:190.0 ,
                          child:  ElevatedButton(


                            onPressed: (){
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) =>RS()),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,),
                            child: Column(

                                children:[
                                  Text('Ajouter radio ou scanner',
                                    style: TextStyle(
                                      fontSize: 14.0,
                                      color: Colors.black,

                                    ),
                                  ),
                                ] ),
                          ),


                        ),



                      ),
                      Card(


                        child: Container(
                          //  color: Colors.deepOrangeAccent,
                          height:90.0,
                          width:190.0 ,
                          decoration: BoxDecoration(
                            //border: Border.all(
                            //color: Colors.black,
                            //  width: 1,
                            // )

                          ),
                          child:  ElevatedButton(


                            onPressed: (){
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) =>Ajout()),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,),
                            child: Column(
                                children:[
                                  Text('Ajouter Certeficat',
                                    style: TextStyle(
                                      fontSize: 16.0,
                                      color: Colors.black,

                                    ),
                                  ),
                                ] ),
                          ),


                        ),

                      ),




                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Card(


                        child: Container(
                          //  color: Colors.deepOrangeAccent,
                          height:190.0,
                          width:190.0 ,
                          child:  ElevatedButton(


                            onPressed: (){
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) =>Infoperso(username: username,)),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,),
                            child: Column(

                                children:[ Image.asset('assets/images/survey-g5953ccd32_1280.png',
                                  fit: BoxFit.fill,

                                ),
                                  Text('Informations Personnels',
                                    style: TextStyle(
                                      fontSize: 12.0,
                                      color: Colors.black,

                                    ),
                                  ),
                                ] ),
                          ),


                        ),



                      ),
                      Card(


                        child: Container(
                          //  color: Colors.deepOrangeAccent,
                          height:190.0,
                          width:190.0 ,
                          decoration: BoxDecoration(
                            //border: Border.all(
                            //color: Colors.black,
                            //  width: 1,
                            // )

                          ),
                          child:  ElevatedButton(


                            onPressed:() async {

                        // Sign out the current user
                        await FirebaseAuth.instance.signOut();
                        // Navigate back to the login page
                        Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(builder: (context) => Login()),
                        (Route<dynamic> route) => false,
                        );

                        },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,),
                            child: Column(
                                children:[ Image.asset('assets/images/medicine-gd9bf039d5_1280.png',
                                  fit: BoxFit.fill,

                                ),
                                  Text('Traitements en cours',
                                    style: TextStyle(
                                      fontSize: 12.0,
                                      color: Colors.black,

                                    ),
                                  ),
                                ] ),
                          ),


                        ),

                      ),




                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Card(


                        child: Container(
                          //  color: Colors.deepOrangeAccent,
                          height:190.0,
                          width:190.0 ,
                          child:  ElevatedButton(


                            onPressed: (){},
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,),
                            child: Column(
                                children:[ Image.asset('assets/images/database-search-g8da445ea9_1280.png',
                                  fit: BoxFit.fill,

                                ),
                                  Text('Historique des maladies',
                                    style: TextStyle(
                                      fontSize: 10.0,
                                      color: Colors.black,

                                    ),
                                  ),
                                ] ),
                          ),


                        ),



                      ),
                      Card(


                        child: Container(
                          //  color: Colors.deepOrangeAccent,
                          height:190.0,
                          width:190.0 ,
                          decoration: BoxDecoration(
                            //border: Border.all(
                            //color: Colors.black,
                            //  width: 1,
                            // )

                          ),
                          child:  ElevatedButton(


                            onPressed: (){
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) =>  Htraitement(username: username,)),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,),
                            child: Column(
                                children:[ Image.asset('assets/images/patient.png',
                                  fit: BoxFit.fill,

                                ),
                                  Text('Historique des traitements',
                                    style: TextStyle(
                                      fontSize: 12.0,
                                      color: Colors.black,

                                    ),
                                  ),
                                ] ),
                          ),


                        ),

                      ),




                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Card(


                        child: Container(
                          //  color: Colors.deepOrangeAccent,
                          height:190.0,
                          width:190.0 ,
                          child:  ElevatedButton(


                            onPressed: () {
                          Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>Allergieetmaladie(username: "Engel",)),
                          );
                          },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,),
                            child: Column(
                                children:[ Image.asset('assets/images/lungs-gc35adae72_1280.png',
                                  fit: BoxFit.fill,

                                ),
                                  Text('Maladies chroniques et allergies',
                                    style: TextStyle(
                                      fontSize: 10.0,
                                      color: Colors.black,

                                    ),
                                  ),
                                ] ),
                          ),


                        ),



                      ),
                      Card(


                        child: Container(
                          //  color: Colors.deepOrangeAccent,
                          height:190.0,
                          width:190.0 ,
                          decoration: BoxDecoration(
                            //border: Border.all(
                            //color: Colors.black,
                            //  width: 1,
                            // )

                          ),
                          child:  ElevatedButton(


                            onPressed: (){
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) =>ImageList()),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,),
                            child: Column(
                                children:[ Image.asset('assets/images/stethoscope-icon-gafc31bdb6_1280.png',
                                  fit: BoxFit.fill,

                                ),
                                  Text('Maladies en cours',
                                    style: TextStyle(
                                      fontSize: 10.0,
                                      color: Colors.black,

                                    ),
                                  ),
                                ] ),
                          ),


                        ),

                      ),




                    ],
                  ),

                ]),


          ),
        ),

      ),




    );

  }
}
