import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:path/path.dart';



class RS extends StatefulWidget {
  @override
  _RS createState() => _RS();
}

class _RS extends State<RS> {
  late File _image;
  final picker = ImagePicker();
  TextEditingController _textController = TextEditingController();
  DateTime _selectedDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    _image = File(''); // initialiser la variable _image avec une valeur nulle
  }

  Future getImage() async {
    final pickedFile = await picker.getImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
        uploadImageToFirebaseStorage(_image); // Upload the image to Firebase storage
      } else {
        print('No image selected.');
      }
    });
  }
  Future<void> uploadImageToFirebaseStorage(File file) async {
    try {
      // Create a reference to the Firebase storage location
      String fileName = basename(file.path);
      firebase_storage.Reference reference =
      firebase_storage.FirebaseStorage.instance.ref('images/$fileName');

      // Upload the file to Firebase storage
      await reference.putFile(file);

      // Get the download URL of the uploaded file
      String downloadURL = await reference.getDownloadURL();
      print('Download URL: $downloadURL');
    } catch (e) {
      print('Error uploading image to Firebase storage: $e');
    }
  }
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Color.fromRGBO(69, 169, 230, 1),
          toolbarHeight: 80.0,
          title: Text('Radio et Scanners', style:TextStyle(fontSize: 30.0),),
        ),
        body: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20,),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Nom du fichier ',
                  labelStyle: TextStyle(color: Colors.grey),
                  hintText: 'Ex: Radio de poignes ',
                  hintStyle: TextStyle(color: Colors.grey),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.blue, width: 2.0),
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ),
              SizedBox(height: 16,),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Observation du Docteur ',
                  labelStyle: TextStyle(color: Colors.grey),
                  hintText: 'Ex: casse au niveau de poignees ',
                  hintStyle: TextStyle(color: Colors.grey),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.blue, width: 2.0),
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ),
              Center(
                child:Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextButton(
                      onPressed: null,
                      child: Text(
                        '${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}',
                        style: TextStyle(fontSize: 30.0, color: Color.fromRGBO(69, 169, 230, 1),),
                      ),
                    ),

                  ],
                ),
              ),


              SizedBox(height: 30.0),
              Center(
                child: _image.path.isEmpty
                    ? Text('Aucune image sélectionée ',   style: TextStyle(
                  fontSize: 22.0,
                ),)
                    : Image.file(_image),
              ),
              SizedBox(height: 16.0),
              Center(
                child: ElevatedButton(
                  onPressed: getImage,
                  child: Text('Telecharger une photo ',   style: TextStyle(
                    fontSize: 22.0,
                  ),),
                  style: ElevatedButton.styleFrom(
                    primary: Color.fromRGBO(69, 169, 230, 1),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    minimumSize: Size(120, 50), // définir la taille minimale
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

