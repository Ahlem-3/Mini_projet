
import 'dossier.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class AccountChoice extends StatelessWidget {
   AccountChoice({super.key , required this.username});
  String username;

  @override
  Widget build(BuildContext context) {

    return SafeArea(

      child: Scaffold(

        body: SingleChildScrollView(
          child: Center(
            // Center is a layout widget. It takes a single child and positions it
            // in the middle of the parent.
              child: Column(

                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Container(
                        height: 100.0,

                        child: Image.asset('assets/images/logo2.png')
                    ),
                    Text(username),
                    SizedBox(
                      height: 30.0,
                    ),
                    Padding(
                      padding: EdgeInsets.all(18.0),
                    child: Text(
                        'choisir un rôle',
                    style: TextStyle(

                      fontSize: 40.0,
                      fontWeight: FontWeight.bold,
                    ),

                    ),
                    ),
                    Padding(
                      padding: EdgeInsets.all(18.0),
                      child: Text(
                        'sous quel compte voulez-vous vous connecter ?',
                        style: TextStyle(

                          fontSize: 16.0,
                          //fontWeight: FontWeight.bold,
                        ),

                      ),
                    ),
                    SizedBox(
                      height: 20.0,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                       Card(


                              child: Container(
                              //  color: Colors.deepOrangeAccent,
                                height:190.0,
                                width:190.0 ,
                                child:  ElevatedButton(


                                      onPressed: (){},
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.white,),
                                          child: Column(
                                            children:[ Image.asset('assets/images/doctor.png',
                                              fit: BoxFit.fill,

                                            ),
                                              Text('Docteur',
                                              style: TextStyle(
                                                fontSize: 20.0,
                                                color: Colors.black,

                                              ),
                                              ),
                                  ] ),
                                        ),


                                  ),



                       ),
                        Card(


                          child: Container(
                            //  color: Colors.deepOrangeAccent,
                            height:190.0,
                            width:190.0 ,
                            decoration: BoxDecoration(
                              //border: Border.all(
                              //color: Colors.black,
                            //  width: 1,
                           // )

                            ),
                            child:  ElevatedButton(


                              onPressed: (){
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) =>  Dossier(username: username,)),
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.white,),
                              child: Column(
                                  children:[ Image.asset('assets/images/patient.png',
                                    fit: BoxFit.fill,

                                  ),
                                    Text('Patient',
                                      style: TextStyle(
                                        fontSize: 20.0,
                                        color: Colors.black,

                                      ),
                                    ),
                                  ] ),
                            ),


                          ),

                        ),




                      ],
                    ),
                     Padding(
                        padding: EdgeInsets.only(top: 265.0),
                        child:  Container(
                          //  color: Colors.green.shade400,
                          width: 380.0,
                          decoration: BoxDecoration(
                            color: Color.fromRGBO(41, 145, 178, 20),
                            borderRadius: BorderRadius.circular(5),
                          ),
                          child:  TextButton(
                              style: ButtonStyle(
                                foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                                overlayColor: MaterialStateProperty.resolveWith<Color?>(
                                      (Set<MaterialState> states) {
                                    if (states.contains(MaterialState.hovered))
                                      return Colors.blue.withOpacity(0.04);
                                    if (states.contains(MaterialState.focused) ||
                                        states.contains(MaterialState.pressed))
                                      return Colors.blue.withOpacity(0.12);
                                    return null; // Defer to the widget's default.
                                  },
                                ),
                              ),
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) =>  AccountChoice(username:username)),
                                );
                              },
                              child: const Text('Continuer')
                          ),

                        ),

                     ),
                  ]),


          ),
        ),

        ),




      );

  }
}
