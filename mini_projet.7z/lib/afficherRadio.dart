import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';

class ImageList extends StatelessWidget {
  final storage = FirebaseStorage.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('List of Images'),
      ),
      body: FutureBuilder(
        future: storage.ref('images').listAll(),
        builder: (context, AsyncSnapshot<ListResult> snapshot) {
          if (!snapshot.hasData) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
          return ListView.builder(
            itemCount: snapshot.data!.items.length,
            itemBuilder: (context, index) {
              Reference ref = snapshot.data!.items[index];
              String fileName = ref.name;
              return ListTile(
                title: Text(fileName),
                onTap: () async {
                  String url = await ref.getDownloadURL();
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ImageScreen(
                        imageURL: url,
                        fileName: fileName,
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}

class ImageScreen extends StatelessWidget {
  final String imageURL;
  final String fileName;

  ImageScreen({required this.imageURL, required this.fileName});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(fileName),
      ),
      body: Center(
        child: Image.network(imageURL),
      ),
    );
  }
}
