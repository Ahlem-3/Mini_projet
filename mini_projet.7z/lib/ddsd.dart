

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Certeficat2 extends StatelessWidget {
  const Certeficat2({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(


        child: Scaffold(
            appBar: AppBar(
              toolbarHeight: 60.0,
              elevation: 10,
              leading:Container(

                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(35),
                  child: Image.asset('assets/images/user.png', fit: BoxFit.fill),
                ),
              ),
              backgroundColor: Color.fromRGBO(84, 160, 255, 1),
            ),
            body: SingleChildScrollView(
              child: Column(
                children: [
                  TextField(


                    decoration: InputDecoration(
                      fillColor: Colors.white,
                      label:const Center(
                        child: Text( "Medicament"),

                      ) ,


                      border: UnderlineInputBorder(



                      ),
                    ),


                  ),

                  Container(
                    //width: 65s0.0,
                    child: CheckboxListTile(
                      title: const Text('Matin'),
                      value: true,
                      secondary: const Icon(Icons.sunny),
                      onChanged: (bool? value){


                        value=false;
                      },),
                  ),
                  Container(
                    child: CheckboxListTile(
                      title: const Text('Midi'),
                      value: true,
                      secondary: const Icon(Icons.sunny),
                      onChanged: (bool? value){


                        value=false;
                      },),

                  ),
                  Container(
                    child: CheckboxListTile(
                      title: const Text('soir'),
                      value: true,
                      secondary: const Icon(Icons.nightlife),
                      onChanged: (bool? value){


                        value=false;
                      },),

                  ),
                  SizedBox(
                    height: 30.0,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(
                        child: Column(
                          children: [
                            Text('avant'),
                            Radio(
                                value: "radio value",
                                groupValue: "group value",
                                onChanged: (value){
                                  print(value); //selected value
                                }
                            )
                          ],
                        ),



                      ),
                      Container(
                        child: Column(
                          children: [
                            Text('pendant'),
                            Radio(
                                value: "radio value",
                                groupValue: "group value",
                                onChanged: (value){
                                  print(value); //selected value
                                }
                            )
                          ],
                        ),),


                      Container(
                        child: Column(
                          children: [
                            Text('aprés'),
                            Radio(
                                value: "radio value",
                                groupValue: "group value",
                                onChanged: (value){
                                  print(value); //selected value
                                }
                            )
                          ],
                        ),),
                    ],



                  )






                ],
                // Center is a layout widget. It takes a single child and positions it
                // in the middle of the parent.

              ),




            )));

  }
}
