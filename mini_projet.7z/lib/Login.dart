import 'package:mini_projet/accountchoice.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'dossier.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class Login extends StatefulWidget {
  Login({Key? key}) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  TextEditingController username = TextEditingController();
  TextEditingController password = TextEditingController();

  CollectionReference usersRef =
  FirebaseFirestore.instance.collection("users");

  Future<void> signIn() async {
    try {
      // Sign in the user with the entered email (which will be the ID) and password
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: username.text.trim() + "@gmail.com",
        password: password.text.trim(),
      );

      // Retrieve the user data from Firestore
      DocumentSnapshot userData = await usersRef.doc(username.text.trim().substring(0, 1).toUpperCase() + username.text.trim().substring(1)).get();

      // Check if the user is a doctor
      if (userData.exists && userData.get("role") == "medecin") {
        // If the user is a doctor, navigate to the doctor page
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => AccountChoice(username: username.text.trim().substring(0, 1).toUpperCase() + username.text.trim().substring(1)),
          ),
        );
      } else if (userData.exists && userData.get("role") == "patient") {
        // If the user is a doctor, navigate to the doctor page
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) =>
                Dossier(username: username.text.trim().substring(0, 1).toUpperCase() +
                    username.text.trim().substring(1)),
          ),
        );
      }
    } catch (e) {
      // If there is an error signing in, show an error message
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Error"),
            content: Text(e.toString()),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text("OK"),
              ),
            ],
          );
        },
      );
    }
  }



  @override
Widget build(BuildContext context) {

    return StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
    builder: (context, snapshot) {
    if (snapshot.connectionState == ConnectionState.waiting) {
    // Show a loading spinner if the authentication state is still loading
    return Center(
    child: CircularProgressIndicator(),
    );
    } else if (snapshot.hasData) {
    // If the user is already authenticated, navigate to the account choice page
    return AccountChoice(username: username.text.trim());
    } else {
    // If the user is not authenticated, show the login page
    return SafeArea(
    child: Scaffold(

      body: SingleChildScrollView(
        child: Center(
          // Center is a layout widget. It takes a single child and positions it
          // in the middle of the parent.
            child: Column(

                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[

                  Container(
                      height: 340.0,

                      child: Image.asset('assets/images/logo2.png')),


                  Padding(
                    padding: const EdgeInsets.only(top:15.0,left: 30.0,right: 30.0,bottom: 15.0),
                    child: TextField(
                      controller: username,
                      decoration: InputDecoration(
                        fillColor: Colors.white,
                        labelText: "Username",
                        prefixIcon: const Icon(Icons.perm_identity),

                        border: OutlineInputBorder(

                          borderSide: const BorderSide(

                          ),
                          borderRadius: BorderRadius.circular(35.0),
                        ),
                      ),

                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 30.0,right: 30.0),
                    child: TextField(
                      controller: password,

                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.lock),
                        fillColor: Colors.black,
                        labelText: "Password",
                        border: OutlineInputBorder(

                          borderSide: const BorderSide(

                          ),
                          borderRadius: BorderRadius.circular(35.0),
                        ),
                      ),

                    ),
                  ),
                  const SizedBox(
                    height: 25.0,
                  ),
                  Container(
                    //  color: Colors.green.shade400,
                    width: 180.0,
                    decoration: BoxDecoration(
                      color:Color.fromRGBO(41, 145, 178, 20),
                      borderRadius: BorderRadius.circular(35),
                    ),
                    child:  TextButton(
                        style: ButtonStyle(
                          foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                          overlayColor: MaterialStateProperty.resolveWith<Color?>(
                                (Set<MaterialState> states) {
                              if (states.contains(MaterialState.hovered))
                                return Colors.blue.withOpacity(0.04);
                              if (states.contains(MaterialState.focused) ||
                                  states.contains(MaterialState.pressed))
                                return Colors.blue.withOpacity(0.12);
                              return null; // Defer to the widget's default.
                            },
                          ),
                        ),
                        onPressed: signIn,
                        child: const Text('se connecter')
                    ),

                  ),

                  const SizedBox(height: 15.0,),
                  Padding(
                    padding:const EdgeInsets.only(left: 0.0),
                    child: TextButton(

                        onPressed: () { },
                        child: const Text("Besoin d'aide ?")

                    ),




                  )  ,




                ])
        ),
      ),





    ),


  );

}
});
  }}
