import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Allergieetmaladie extends StatefulWidget {
  Allergieetmaladie({Key? key, required this.username});
  final String username;
  @override
  _Allergieetmaladie createState() => _Allergieetmaladie();
}

class _Allergieetmaladie extends State<Allergieetmaladie> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          stream: FirebaseFirestore.instance
              .collection('users')
              .doc("Engel")
              .snapshots(),
          builder: (BuildContext context,
              AsyncSnapshot<DocumentSnapshot<Map<String, dynamic>>> snapshot) {
            if (snapshot.hasError) {
              return const Text('Something went wrong');
            }
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Text("Loading");
            }
            Map<String, dynamic> data =
            snapshot.data!.data()! as Map<String, dynamic>;
            return ListView(
              children: [
                Text('Allergies'),
                ...data['alergies']
                    .map<Widget>((e) => ListTile(
                  title: Text(e.toString()),
                ))
                    .toList(),
                Text('Maladie Chronique'),
                ...data['maladiechronique']
                    .map<Widget>((e) => ListTile(
                  title: Text(e.toString()),
                ))
                    .toList(),
              ],
            );
          },
        ),
      ),
    );
  }
}
